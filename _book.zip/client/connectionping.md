# 连接Ping

#### 功能说明
连接Ping


#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/system/connection/ping |
| 请求头部 |  |
| HTTP方式 | GET |

* #### 输入参数说明

| 参数名称 | 参数类型 | 是否必须 | 描述 |
| :--- | :--- | :--- | :--- |
| timeStamp| Long| 是 | 时间 |


* #### HTTP 请求示例
* #### 返回参数

  字符串，不是json，返回OK或者FAIL。返回FAIL时HTTP code是400

* #### 响应示例：

  OK

* #### 异常返回值
无



