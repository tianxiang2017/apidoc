## 下载文件

#### 功能说明

下载文件到本地

#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/file/download|
| 请求头部 | Content-Type:application/json;charset=utf-8 |
| HTTP方式 | GET |

* #### 输入参数说明

| 参数名称 | 参数类型 | 是否必须 | 参数描述 |
| :--- | :--- | :--- | :--- |
|id | Integer\(10\) | 是 |文件id |


* #### HTTP 请求示例
\[md-device域名\]/file/download?id=23



* #### 返回参数
一个文件


* #### 响应示例：

无

* #### 异常返回值

无



