## 处理文件

#### 功能说明

处理文件，文件处理后将从OSS平台删除，后续不能再下载

#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/file/processFile|
| 请求头部 | Content-Type:application/json;charset=utf-8 |
| HTTP方式 | POST|

* #### 输入参数说明

| 参数名称 | 参数类型 | 是否必须 | 参数描述 |
| :--- | :--- | :--- | :--- |
|id | Integer\(10\) | 是 |文件id |



* #### HTTP 请求示例


* #### 返回参数
无


* #### 响应示例：

success

* #### 异常返回值

failed



