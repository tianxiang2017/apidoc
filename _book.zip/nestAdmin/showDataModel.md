## Nest 显示用户的DataModel

#### 功能说明

Nest 显示用户的DataModel

#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/nest/showDataModel|
| 请求头部 | Content-Type:application/json;charset=utf-8 |
| HTTP方式 | GET |

* #### 输入参数说明

| 参数名称 | 参数类型 | 是否必须 | 参数描述 |
| :--- | :--- | :--- | :--- |
|accountId|Intege\(10\)|是|用户id|



* #### HTTP 请求示例


* #### 返回参数

无 


* #### 响应示例：

无

* #### 异常返回值

无



