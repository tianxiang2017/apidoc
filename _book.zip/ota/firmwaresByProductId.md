# 获取产品的所有固件包

#### 功能说明

现在已经修改，直接返回空。
productId：产品Id

#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/firmwares/all/product/{productId} |
| 请求头部 | Content-Type:application/json;charset=utf-8 |
| HTTP方式 | POST |

* * #### 输入参数说明

无

* #### HTTP 请求示例

  ```
  curl -X POST \
  http://openapi.fantem-gateway.com/firmwares/all/product/7 
  ```

* #### 返回参数

无

* #### 响应示例：
[]

* #### 异常返回值

  无






























