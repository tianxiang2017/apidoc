## 导出用户统计

#### 功能说明

导出用户统计。导出为excel文件。导出全部数据

#### 调用接口说明

* #### HTTP配置

| 配置项 | 取值 |
| --- | --- |
| URL | \[域名\]/statDay/reportExport|
| 请求头部 | Content-Type:application/json;charset=utf-8 |
| HTTP方式 | GET |

* #### 输入参数说明
无

* #### HTTP 请求示例


* #### 返回参数
一个excel文件


* #### 响应示例：

无

* #### 异常返回值

无



